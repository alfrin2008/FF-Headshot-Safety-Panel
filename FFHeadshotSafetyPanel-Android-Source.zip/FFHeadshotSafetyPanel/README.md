# FF Headshot Safety Panel

A standalone Android companion app built with Kotlin + Jetpack Compose.

## App sections
- Headshot reaction training (standalone in-app drill)
- Account-safety checklist
- Safe manual HUD/control guidance

## Build the APK
1. Install Android Studio (recent stable version).
2. Open this project folder.
3. Allow Gradle sync to finish. Use JDK 17 if prompted.
4. Connect an Android device or start an emulator.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer it to your Android phone and install it. Android may ask you to allow installs from the file manager you used.

For a signed release APK, use Build > Generate Signed Bundle / APK and create a keystore. Keep the keystore and passwords private.

## Using it alongside Free Fire
- Open this app separately and use Headshot to practise reaction speed.
- Open Safety and review the account-protection checklist.
- Open Safe Settings for manual HUD tips.
- Launch Free Fire and apply any desired control/HUD changes inside Free Fire's own Settings/HUD Customization screens.
- This app does not overlay, connect to, automate, modify, or inject into Free Fire.

## Safety
No third-party app can guarantee an account will never be banned. Use the official Free Fire client and avoid mod APKs, injectors, scripts, macros, auto-aim, or anti-cheat bypasses. This app does not request game credentials and works offline.
