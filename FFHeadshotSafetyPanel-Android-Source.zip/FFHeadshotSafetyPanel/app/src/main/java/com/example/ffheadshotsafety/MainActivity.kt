package com.example.ffheadshotsafety

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Bg = Color(0xFF09090D)
private val Panel = Color(0xFF17171F)
private val Red = Color(0xFFFF303B)
private val White = Color(0xFFF5F5F7)
private val Muted = Color(0xFFAAAAB5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var page by remember { mutableStateOf("Home") }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp)) {
                Header()
                Spacer(Modifier.height(20.dp))
                when (page) {
                    "Home" -> HomeScreen(
                        onTrain = { page = "Headshot" },
                        onSafety = { page = "Safety" },
                        onSettings = { page = "Safe Settings" }
                    )
                    "Headshot" -> TrainingScreen()
                    "Safety" -> SafetyScreen()
                    else -> SafeSettingsScreen()
                }
            }
            NavigationBar(containerColor = Panel, contentColor = White) {
                listOf("Home", "Headshot", "Safety", "Safe Settings").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = { Text(when(item) {
                            "Home" -> "⌂"; "Headshot" -> "◎"; "Safety" -> "✓"; else -> "⚙"
                        }, fontSize = 19.sp) },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Red,
                            selectedTextColor = Red,
                            indicatorColor = Color(0xFF332027),
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(Red, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("FF", color = White, fontWeight = FontWeight.Black, fontSize = 19.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("HEADSHOT", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text("TRAINING  /  ACCOUNT SAFETY", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun HomeScreen(onTrain: () -> Unit, onSafety: () -> Unit, onSettings: () -> Unit) {
    Text("WELCOME BACK", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Text("Train smart.\nPlay fair.", color = White, fontSize = 34.sp, fontWeight = FontWeight.Black, lineHeight = 39.sp)
    Spacer(Modifier.height(18.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("HEADSHOT PRACTICE", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Improve your reaction and target tracking with a safe in-app drill.", color = White, fontSize = 15.sp)
            Spacer(Modifier.height(14.dp))
            ActionButton("START TRAINING", onTrain)
        }
    }
    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SmallTile("01", "Training drills", Modifier.weight(1f), onTrain)
        SmallTile("02", "Account safety", Modifier.weight(1f), onSafety)
    }
    Spacer(Modifier.height(12.dp))
    SmallTile("03", "Safe HUD & control tips", Modifier.fillMaxWidth(), onSettings)
    Spacer(Modifier.height(18.dp))
    Text("IMPORTANT", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Text("This companion app does not connect to Free Fire, change game files, automate aiming, or guarantee headshots. Apply any in-game control changes manually.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
}

@Composable
fun SmallTile(number: String, title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(number, color = Red, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun ActionButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Text(label, color = White, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
    }
}

@Composable
fun TrainingScreen() {
    var running by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(30) }
    var score by remember { mutableIntStateOf(0) }
    var target by remember { mutableIntStateOf(0) }
    var hits by remember { mutableIntStateOf(0) }

    LaunchedEffect(running) {
        if (running) {
            while (seconds > 0 && running) {
                delay(1000)
                seconds--
            }
            if (seconds == 0) running = false
        }
    }

    Text("REACTION DRILL", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Text("Tap the target", color = White, fontSize = 29.sp, fontWeight = FontWeight.Black)
    Text("A simple reflex exercise. It does not interact with the game.", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(18.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatBox("TIME", "${seconds}s", Modifier.weight(1f))
        StatBox("HITS", "$hits", Modifier.weight(1f))
        StatBox("SCORE", "$score", Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Box(Modifier.fillMaxWidth().height(310.dp).background(Color(0xFF20202A), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
        if (running) {
            Box(
                Modifier.offset(x = ((target * 47) % 135 - 67).dp, y = ((target * 61) % 190 - 95).dp)
                    .size(58.dp).background(Red, CircleShape)
                    .clickable {
                        hits++
                        score += 10
                        target = Random.nextInt(1, 1000)
                    },
                contentAlignment = Alignment.Center
            ) { Text("＋", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black) }
        } else {
            Text(if (seconds == 0) "DRILL COMPLETE" else "PRESS START TO BEGIN", color = White, fontWeight = FontWeight.Bold)
        }
    }
    Spacer(Modifier.height(16.dp))
    ActionButton(if (running) "DRILL RUNNING" else if (seconds == 0) "RESTART DRILL" else "START 30-SECOND DRILL") {
        if (!running) {
            seconds = 30
            score = 0
            hits = 0
            target = Random.nextInt(1, 1000)
            running = true
        }
    }
    Spacer(Modifier.height(10.dp))
    OutlinedButton(onClick = { running = false; seconds = 30; score = 0; hits = 0 }, modifier = Modifier.fillMaxWidth()) {
        Text("RESET DRILL", color = White)
    }
}

@Composable
fun StatBox(label: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun SafetyScreen() {
    val items = listOf(
        "Install Free Fire only from official app stores.",
        "Never share your password or one-time verification codes.",
        "Avoid third-party panels, mod APKs, injectors and scripts.",
        "Do not use auto-clickers, macros or aiming automation.",
        "Keep your Google / platform account protected.",
        "Be cautious of websites promising free diamonds or rewards."
    )
    val checked = remember { mutableStateListOf<Boolean>().apply { repeat(items.size) { add(false) } } }
    val count = checked.count { it }
    Text("ACCOUNT SAFETY", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Text("Protect your account", color = White, fontSize = 29.sp, fontWeight = FontWeight.Black)
    Text("$count of ${items.size} safety steps checked", color = Muted)
    Spacer(Modifier.height(12.dp))
    LinearProgressIndicator(progress = { count.toFloat() / items.size }, modifier = Modifier.fillMaxWidth(), color = Red, trackColor = Panel)
    Spacer(Modifier.height(14.dp))
    items.forEachIndexed { i, item ->
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked[i], onCheckedChange = { checked[i] = it }, colors = CheckboxDefaults.colors(checkedColor = Red))
                Spacer(Modifier.width(8.dp))
                Text(item, color = White, fontSize = 13.sp)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Safety note", color = Red, fontWeight = FontWeight.Bold)
    Text("No third-party app can guarantee that an account will never be banned. Follow the game's current official rules and avoid tools that alter or automate gameplay.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
}

@Composable
fun SafeSettingsScreen() {
    Text("SAFE IN-GAME SETTINGS", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Text("Manual control tips", color = White, fontSize = 29.sp, fontWeight = FontWeight.Black)
    Text(
        "Use Free Fire's own Settings and HUD Customization menus. This app only gives guidance; it does not change game settings for you.",
        color = Muted, fontSize = 13.sp, lineHeight = 19.sp
    )
    Spacer(Modifier.height(16.dp))
    val tips = listOf(
        "Open Free Fire → Settings → Controls to review your control layout.",
        "Use the in-game HUD Customization screen to move and resize buttons.",
        "Choose a fire-button position and size that feels comfortable on your device.",
        "Make small changes, then test them in Training Mode before playing ranked matches.",
        "Avoid third-party injectors, mod APKs, scripts, macros and auto-aim tools."
    )
    tips.forEachIndexed { index, tip ->
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                Text("${index + 1}.", color = Red, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(10.dp))
                Text(tip, color = White, fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("No anti-ban guarantee", color = Red, fontWeight = FontWeight.Bold)
    Text(
        "There is no legitimate third-party anti-ban switch. The safest approach is to use the official game client and follow the current Free Fire rules.",
        color = Muted, fontSize = 13.sp, lineHeight = 19.sp
    )
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = White,
    unfocusedTextColor = White,
    focusedBorderColor = Red,
    unfocusedBorderColor = Muted,
    focusedLabelColor = Red,
    unfocusedLabelColor = Muted,
    cursorColor = Red
)
